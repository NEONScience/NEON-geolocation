Sys.setenv(R_TESTS="")
library(testthat)
library(geoNEON)

test_check("geoNEON")
